/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 *
 * @author Aluno
 */
public class Suspeitos {
    
   private String nomesuspeito;
   private String sexo;
   private String ocupacao;
   private String esporte;
   private String cabelo;
   private String carro;
   private String tracos;
   private String outros;
   private Integer suspeitoid;
   private byte[] imagem;

    public String getNomesuspeito() {
        return nomesuspeito;
    }

    public void setNomesuspeito(String nomesuspeito) {
        this.nomesuspeito = nomesuspeito;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getOcupacao() {
        return ocupacao;
    }

    public void setOcupacao(String ocupacao) {
        this.ocupacao = ocupacao;
    }

    public String getEsporte() {
        return esporte;
    }

    public void setEsporte(String esporte) {
        this.esporte = esporte;
    }

    public String getCabelo() {
        return cabelo;
    }

    public void setCabelo(String cabelo) {
        this.cabelo = cabelo;
    }

    public String getCarro() {
        return carro;
    }

    public void setCarro(String carro) {
        this.carro = carro;
    }

    public String getTracos() {
        return tracos;
    }

    public void setTracos(String tracos) {
        this.tracos = tracos;
    }

    public String getOutros() {
        return outros;
    }

    public void setOutros(String outros) {
        this.outros = outros;
    }

    public Integer getSuspeitoid() {
        return suspeitoid;
    }

    public void setSuspeitoid(Integer suspeitoid) {
        this.suspeitoid = suspeitoid;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }
    
}
