/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Modelo;

/**
 *
 * @author Aluno
 */
public class Cidades {
   
   private String nomecidade;
   private String dica1;
   private String dica2;
   private String dica3;
   private String item1;
   private String item2;
   private String descricao;
   private Integer cidadeid;
   private byte[] imagem;

    public String getNomecidade() {
        return nomecidade;
    }

    public void setNomecidade(String nomecidade) {
        this.nomecidade = nomecidade;
    }

    public String getDica1() {
        return dica1;
    }

    public void setDica1(String dica1) {
        this.dica1 = dica1;
    }

    public String getDica2() {
        return dica2;
    }

    public void setDica2(String dica2) {
        this.dica2 = dica2;
    }

    public String getDica3() {
        return dica3;
    }

    public void setDica3(String dica3) {
        this.dica3 = dica3;
    }

    public String getItem1() {
        return item1;
    }

    public void setItem1(String item1) {
        this.item1 = item1;
    }

    public String getItem2() {
        return item2;
    }

    public void setItem2(String item2) {
        this.item2 = item2;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getCidadeid() {
        return cidadeid;
    }

    public void setCidadeid(Integer cidadeid) {
        this.cidadeid = cidadeid;
    }

    public byte[] getImagem() {
        return imagem;
    }

    public void setImagem(byte[] imagem) {
        this.imagem = imagem;
    }
    
}
